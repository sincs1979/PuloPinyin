#!/usr/bin/env bash
# Install 部落输入法 fcitx5 addon for the current user (~/.local).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PREFIX="${PREFIX:-$HOME/.local}"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/buluo-ime"

mkdir -p \
  "$PREFIX/lib/fcitx5" \
  "$PREFIX/share/fcitx5/addon" \
  "$PREFIX/share/fcitx5/inputmethod" \
  "$DATA"

cp "$HERE/lib/fcitx5/buluo.so" "$PREFIX/lib/fcitx5/buluo.so"
cp "$HERE/share/fcitx5/addon/buluo.conf" "$PREFIX/share/fcitx5/addon/buluo.conf"
cp "$HERE/share/fcitx5/inputmethod/buluo.conf" "$PREFIX/share/fcitx5/inputmethod/buluo.conf"
cp "$HERE/share/buluo-ime/system.dict" "$DATA/system.dict"

echo "Installed 部落输入法 → $PREFIX"
echo "  addon: $PREFIX/lib/fcitx5/buluo.so"
echo "  dict:  $DATA/system.dict"
echo
echo "Next:"
echo "  1. Restart fcitx5  (fcitx5 -r   or log out/in)"
echo "  2. fcitx5-configtool → add 部落输入法"
echo "  3. Type zhongguo, Space → 中国"
