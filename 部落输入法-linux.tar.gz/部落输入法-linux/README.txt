部落输入法 0.1.0 (Linux / fcitx5)

Requires: fcitx5

  chmod +x install.sh
  ./install.sh

Then restart fcitx5 and enable 部落输入法 in fcitx5-configtool.
